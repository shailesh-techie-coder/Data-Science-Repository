####################################################################################################
##--Create a New Schema called 'assignment' and use the same for the Analysis
####################################################################################################
CREATE SCHEMA `assignment` ;
use assignment;
SET SQL_SAFE_UPDATES = 0;

####################################################################################################
##--Create a table called Eicher which contains information about the stock transactions of eicher
####################################################################################################
create table assignment.eicher
(
transaction_date char(29),
open_price  float(10,2),
high_price  float(10,2),
low_price  float(10,2),
close_price  float(10,2),
wap  float(15,4),
no_of_shares int,
no_of_trades int,
total_turnover_rs bigint,
deliverable_quantity float(10,2),
deli_qty_to_traded_qty  float(10,2),
spread_high_low  decimal(10,2),
spread_close_open  decimal(10,2),
constraint pk_eicher primary key (transaction_date)
);


#################################################################################################
##--Create a table called hero which contains information about the stock transactions of hero
#################################################################################################
create table assignment.hero as 
select * from assignment.eicher;

alter table assignment.hero
add constraint pk_hero primary key (transaction_date);

#################################################################################################
##--Create a table called bajaj which contains information about the stock transactions of bajaj
#################################################################################################
create table assignment.bajaj as 
select * from assignment.eicher;

alter table assignment.bajaj
add constraint pk_bajaj primary key (transaction_date);

#################################################################################################
##--Create a table called tvs which contains information about the stock transactions of tvs
#################################################################################################
create table assignment.tvs as 
select * from assignment.eicher;

alter table assignment.tvs
add constraint pk_tvs primary key (transaction_date);

#####################################################################################################
##--Create a table called Infosys which contains information about the stock transactions of Infosys
#####################################################################################################
create table assignment.infosys as 
select * from assignment.eicher;

alter table assignment.infosys
add constraint pk_infosys primary key (transaction_date);

#################################################################################################
##--Create a table called tcs which contains information about the stock transactions of tcs
#################################################################################################
create table assignment.tcs as 
select * from assignment.eicher;

alter table assignment.tcs
add constraint pk_tcs primary key (transaction_date);

############################
##--Commit the Opearations
############################
commit;

##################################################################################################
##--Steps to follow for Loading Data to MySQL table using Data INFILE
##--1. Stop the MySQL Services through Services.msc
##--2. Change the setting in the my.ini file and set secure-file-priv=""
##--3. Restart the Services of MySQL in the services.msc tab that is opened.
##--4. Place the 6 Files in the location - C:\ProgramData\MySQL\MySQL Server 8.0\Data\assignment
##--5. Run the Below Scripts in the MySQL Workbench
##################################################################################################

###############################################################
##--Script to load data into bajaj table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/Bajaj Auto.csv' INTO TABLE assignment.bajaj 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


###############################################################
##--Script to load data into eicher table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/Eicher Motors.csv' INTO TABLE assignment.eicher 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


###############################################################
##--Script to load data into hero table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/Hero Motocorp.csv' INTO TABLE assignment.hero 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


###############################################################
##--Script to load data into infosys table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/Infosys.csv' INTO TABLE assignment.Infosys 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


###############################################################
##--Script to load data into tcs table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/TCS.csv' INTO TABLE assignment.tcs 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


###############################################################
##--Script to load data into tvs table from file
###############################################################
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/assignment/TVS Motors.csv' INTO TABLE assignment.tvs 
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES (
  transaction_date, open_price, high_price, 
  low_price, close_price, wap, no_of_shares, 
  no_of_trades, total_turnover_rs, 
  @col1, @col2, spread_high_low, spread_close_open
) 
SET 
  deliverable_quantity = nullif(@col1, ''), 
  deli_qty_to_traded_qty = nullif(@col2, '');


############################
##--Commit the Opearations
############################
commit;

####################################
##--Check the counts in each table 
####################################
select count(*) from assignment.bajaj; ##--889 Rows
select count(*) from assignment.eicher; #--#889 Rows
select count(*) from assignment.hero; ##--889 Rows
select count(*) from assignment.infosys; ##--889 Rows
select count(*) from assignment.tcs; ##--889 Rows
select count(*) from assignment.tvs; ##--889 Rows

####################################
##--Update the Date Value for Eicher
####################################
update assignment.eicher
set transaction_date = str_to_date(transaction_date, "%d-%M-%Y");
commit;

alter table assignment.eicher
modify column transaction_date date;

####################################
##--Update the Date Value for hero
####################################
update assignment.hero
set transaction_date = str_to_date(transaction_date, "%d-%M-%Y");
commit;

alter table assignment.hero
modify column transaction_date date;

####################################
##--Update the Date Value for Bajaj
####################################
update assignment.bajaj
set transaction_date = str_to_date(transaction_date, "%d-%M-%Y");
commit;

alter table assignment.bajaj
modify column transaction_date date;

####################################
##--Update the Date Value for TVS
####################################
UPDATE assignment.tvs
set transaction_date = STR_TO_DATE(transaction_date, "%d-%M-%Y");
commit;

ALTER TABLE assignment.tvs
MODIFY COLUMN transaction_date date;

######################################
##--Update the Date Value for Infosys
######################################
update assignment.infosys
set transaction_date = str_to_date(transaction_date, "%d-%M-%Y");
commit;

alter table assignment.infosys
modify column transaction_date date;

####################################
##--Update the Date Value for TCS
####################################
update assignment.tcs
set transaction_date = str_to_date(transaction_date, "%d-%M-%Y");
commit;

alter table assignment.tcs
modify column transaction_date date;

#############################################################
## --Create the New Eicher1 table with the moving averages
#############################################################
create table assignment.eicher1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.eicher
);


#############################################################
## --Create the New Hero1 table with the moving averages
#############################################################

create table assignment.hero1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.hero
);


#############################################################
## --Create the New Bajaj1 table with the moving averages
#############################################################
create table assignment.bajaj1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.bajaj
);

#############################################################
## --Create the New TVS1 table with the moving averages
#############################################################
create table assignment.tvs1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.tvs
);


#############################################################
## --Create the New Infosys1 table with the moving averages
#############################################################

create table assignment.infosys1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.infosys
);


#############################################################
## --Create the New TCS1 table with the moving averages
#############################################################
create table assignment.tcs1 as (
  select 
    transaction_date as 'date', 
    close_price as 'close_price', 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 20 then avg(close_price) over (
        order by 
          transaction_date rows between 19 preceding 
          and current row
      ) else null end, 2
    ) as 20_day_ma, 
    round(
      case when row_number() over (
        order by 
          transaction_date
      ) >= 50 then avg(close_price) over (
        order by 
          transaction_date rows between 49 preceding 
          and current row
      ) else null end, 2
    ) as 50_day_ma 
  from 
    assignment.tcs
);


#############################################################
## --Create the Master Table from all the tables
#############################################################
create table assignment.master as (
  select 
    e.transaction_date as 'date', 
    e.close_price as 'eicher', 
    b.close_price as 'bajaj', 
    h.close_price as 'hero', 
    t.close_price as 'tvs', 
    i.close_price as 'infosys', 
    tc.close_price as 'tcs' 
  from 
    assignment.eicher e, 
    assignment.bajaj b, 
    assignment.hero h, 
    assignment.tvs t, 
    assignment.infosys i, 
    assignment.tcs tc 
  where 
    e.transaction_date = b.transaction_date 
    and e.transaction_date = h.transaction_date 
    and e.transaction_date = t.transaction_date 
    and e.transaction_date = i.transaction_date 
    and e.transaction_date = tc.transaction_date
);

################################################################
## --Check the counts in the Master Table
################################################################
select count(*) from assignment.master; ##--889

################################################################
## --Create the New Table called Eicher2 along with the Signal
################################################################
create table assignment.eicher2 as (
  select 
    date as 'date', 
    close_price as 'close_price', 
    case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal' 
  from 
    assignment.eicher1 
  where 
    50_day_ma is not null
);

################################################################
## --Check the counts in the Eicher2 Table
################################################################
select count(*) from assignment.eicher2; ##--840 rows

################################################################
## --Create the New Table called Hero2 along with the Signal
################################################################
create table assignment.hero2 as (
  select 
    date as 'date', 
    close_price as 'close_price', 
    case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal' 
  from 
    assignment.hero1 
  where 
    50_day_ma is not null
);

################################################################
## --Check the counts in the Hero2 Table
################################################################
select count(*) from assignment.hero2; ##--840 rows

################################################################
## --Create the New Table called Bajaj2 along with the Signal
################################################################
create table assignment.bajaj2 as 
 (
 select date as 'date',
 close_price as 'close_price',
 case
    when (20_day_ma > 50_day_ma) and 
	lag(20_day_ma, 1) over (
        order by date
    ) < lag(50_day_ma, 1) over (
        order by date
    )
	then "BUY"
    when (20_day_ma < 50_day_ma) and 
	lag(20_day_ma, 1) over (
        order by date
    ) > lag(50_day_ma, 1) over (
        order by date
    )
	then "SELL"
    else "HOLD"
end as 'signal'
from assignment.bajaj1
where 50_day_ma is not null
);

################################################################
## --Check the counts in the Bajaj2 Table
################################################################
select count(*) from assignment.bajaj2; ##--840 rows


################################################################
## --Create the New Table called tvs2 along with the Signal
################################################################
create table assignment.tvs2 as (
  select 
    date as 'date', 
    close_price as 'close_price', 
    case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal' 
  from 
    assignment.tvs1 
  where 
    50_day_ma is not null
);

################################################################
## --Check the counts in the TVS2 Table
################################################################
select count(*) from assignment.tvs2; ##--840 rows

################################################################
## --Create the New Table called Infosys2 along with the Signal
################################################################
create table assignment.infosys2 as (
  select 
    date as 'date', 
    close_price as 'close_price', 
    case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal' 
  from 
    assignment.infosys1 
  where 
    50_day_ma is not null
);

################################################################
## --Check the counts in the Infosys2 Table
################################################################
select count(*) from assignment.infosys2; ##--840 rows


################################################################
## --Create the New Table called TCS2 along with the Signal
################################################################
create table assignment.tcs2 as (
  select 
    date as 'date', 
    close_price as 'close_price', 
    case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal' 
  from 
    assignment.tcs1 
  where 
    50_day_ma is not null
);

################################################################
## --Check the counts in the tcs2 Table
################################################################
select count(*) from assignment.tcs2; ##--840 rows

#############################################################################################
## --User Defined Function to Generate the Signal for Bajaj Stock for a give day
## --Note : Date to be entered in YYYY-MM-DD format to check the Signal value for the date
#############################################################################################

delimiter $$ 
create function assignment.bajaj_stock_signal(n date) 
    returns char(10) deterministic 
begin 
return (
    select 
        `signal` 
    from 
        assignment.bajaj2 
    where 
        date = n
);
end 
$$ delimiter ;
commit;

#############################################################################################
## --User Defined Function to Generate the Signal for Bajaj Stock for a give day
## --Note : Date to be entered in YYYY-MM-DD format to check the Signal value for the date
#############################################################################################
##--Query to check for a Stock which is on "HOLD"
select bajaj_stock_signal('2015-03-13') as bajaj_signal;
##--HOLD

##--Query to check for a Stock which we can "BUY"
select bajaj_stock_signal('2015-05-18') as bajaj_signal ;
#--BUY

##--Query to check for a Stock which we can "SELL"
select bajaj_stock_signal('2015-08-24') as bajaj_signal ; 
#--SELL


#########################################################
##--Counts of Different Stocks with respective signals
#########################################################

select distinct `signal` , count(1) as 'count'
from assignment.bajaj2
group by `signal`;
#HOLD - 817
#BUY - 12
#SELL - 11

select distinct `signal` , count(1) as 'count'
from assignment.eicher2
group by `signal`;
#HOLD - 827
#BUY - 6
#SELL - 7

select distinct `signal` , count(1) as 'count'
from assignment.hero2
group by `signal`;
#HOLD - 822
#BUY - 9
#SELL - 9

select distinct `signal` , count(1) as 'count'
from assignment.infosys2
group by `signal`;
#HOLD - 822
#BUY - 9
#SELL - 9

select distinct `signal` , count(1) as 'count'
from assignment.tcs2
group by `signal`;
#HOLD - 815
#BUY - 12
#SELL - 13

select distinct `signal` , count(1) as 'count'
from assignment.tvs2
group by `signal`;
#HOLD - 824
#BUY - 8
#SELL - 8

######################################
##--Bajaj Stock Analysis
######################################

	select 
		date as 'date',
		close_price as 'close_price',
		20_day_ma as '20_day_ma',
		50_day_ma as '50_day_ma',
		 case when (20_day_ma > 50_day_ma) 
		and lag(20_day_ma, 1) over (
		  order by 
			date
		) < lag(50_day_ma, 1) over (
		  order by 
			date
		) then "BUY" when (20_day_ma < 50_day_ma) 
		and lag(20_day_ma, 1) over (
		  order by 
			date
		) > lag(50_day_ma, 1) over (
		  order by 
			date
		) then "SELL" else "HOLD" end as 'signal'

	 from assignment.bajaj1
	 where 50_day_ma is not null;
 
######################################
##--Eicher Stock Analysis
######################################

select 
	date as 'date',
    close_price as 'close_price',
    20_day_ma as '20_day_ma',
    50_day_ma as '50_day_ma',
     case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal'

 from assignment.eicher1
 where 50_day_ma is not null;
 
######################################
##--Infosys Stock Analysis
######################################

select 
	date as 'date',
    close_price as 'close_price',
    20_day_ma as '20_day_ma',
    50_day_ma as '50_day_ma',
     case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal'

 from assignment.infosys1
 where 50_day_ma is not null;
 
######################################
##--TCS Stock Analysis
######################################

select 
	date as 'date',
    close_price as 'close_price',
    20_day_ma as '20_day_ma',
    50_day_ma as '50_day_ma',
     case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal'

 from assignment.tcs1
 where 50_day_ma is not null;
 
######################################
##--TVS Stock Analysis
######################################

select 
	date as 'date',
    close_price as 'close_price',
    20_day_ma as '20_day_ma',
    50_day_ma as '50_day_ma',
     case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal'

 from assignment.tvs1
 where 50_day_ma is not null;

######################################
##--Hero Stock Analysis
######################################

select 
	date as 'date',
    close_price as 'close_price',
    20_day_ma as '20_day_ma',
    50_day_ma as '50_day_ma',
     case when (20_day_ma > 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) < lag(50_day_ma, 1) over (
      order by 
        date
    ) then "BUY" when (20_day_ma < 50_day_ma) 
    and lag(20_day_ma, 1) over (
      order by 
        date
    ) > lag(50_day_ma, 1) over (
      order by 
        date
    ) then "SELL" else "HOLD" end as 'signal'

 from assignment.hero1
 where 50_day_ma is not null;

